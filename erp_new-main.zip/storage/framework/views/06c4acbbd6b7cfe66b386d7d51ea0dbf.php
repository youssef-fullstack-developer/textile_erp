<!--begin::Header-->

<div id="kt_header" class="header header-fixed ">
    <!--begin::Container-->
    <div class="container-fluid  d-flex align-items-stretch justify-content-between">
        <!--begin::Header Menu Wrapper-->
        <div class="header-menu-wrapper header-menu-wrapper-left" id="kt_header_menu_wrapper">
            <!--begin::Header Logo-->
            <div class="header-logo">
                <a href="/dashboard">
                    
                </a>
            </div>
            <!--end::Header Logo-->
            <!--begin::Header Menu-->
            <div id="kt_header_menu" class="header-menu header-menu-mobile  header-menu-layout-default ">
                <!--begin::Header Nav-->
                <ul class="menu-nav">
                    <li class="menu-item" aria-haspopup="true"><a href="/dashboard" class="menu-link "><span
                                class="menu-text">Dashboard</span></a></li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true"><a href="javascript:;" class="menu-link menu-toggle"><span
                                class="menu-text">Masters</span><span class="menu-desc"></span><i
                                class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-fixed menu-submenu-left" style="width: 1000px">
                            <div class="menu-subnav">
                                <ul class="menu-content">
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('invoice_settings.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">E - Invoice Settings</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('certification.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Certification Type</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('consignee.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Consignee</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('shades.index')); ?>" class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Shade Master</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('vendors.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Vendor</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('vendor_groups.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Vendor Group</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('godown.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Godown Location</span></a>
                                            </li>
                                            
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('sales_type.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Sales Master Type</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">GST</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('colors.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Color</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('copart.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Copart</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('contract.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Contract Type</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('agent.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Agent</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('transportation.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Transportation</span></a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('loom_types.index')); ?>" class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Loom Type</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('delivery_terms.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Delivery Items</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('inspection.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Inspection Type</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('packing.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Packing Type</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('mill.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Mill Master</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('qualities.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Quality</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('countries.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Country</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('payment_type.index')); ?>"
                                                   class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Payment types</span></a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('payment_term.index')); ?>"
                                                   class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Payment Terms</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <span class="menu-text">Export</span><span class="menu-desc"></span>
                            <i class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-classic menu-submenu-left" style="width: 400px">
                            <div class="menu-subnav">
                                <ul class="menu-content">
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('buyers.index')); ?>" class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Buyer</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('sales_order.index')); ?>" class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Sales Order</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('packing.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Packing List</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('exports_invoice')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Invoice List</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('exports_bill')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Bill of Exchange</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('license.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">License</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('pre_carriage.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Pre-Carriage By</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('port.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Port</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('banks.index')); ?>"
                                                   class="menu-link bg-warning bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Bank</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('container_sizes.index')); ?>"
                                                   class="menu-link bg-warning bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Container Size</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('sales_co_ordinators.index')); ?>"
                                                   class="menu-link bg-warning bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Sales Co Ordinators</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('shipping_terms.index')); ?>"
                                                   class="menu-link bg-warning bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Shipping Terms</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('so_types.index')); ?>"
                                                   class="menu-link bg-warning bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">So Types</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('terms_conditions.index')); ?>"
                                                   class="menu-link bg-warning bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Terms & Conditions</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('units.index')); ?>"
                                                   class="menu-link bg-warning bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Units</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('yarn_certification_types.index')); ?>"
                                                   class="menu-link bg-warning bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn Certification Types</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                                
                            </div>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <span class="menu-text">Domestic</span><span class="menu-desc"></span>
                            <i class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-classic menu-submenu-left">
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.buyer.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Buyer</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.sales_order.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Sales Order</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.contract.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Contract Type</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.challan.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Challan List</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.invoice.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Invoice List</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.yarn.sales_contract.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Sales Contract</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.yarn.challan.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Challan</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.yarn.invoice.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Invoice List</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.yarn.e_invoice.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn E - Invoice List</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('domestic.yarn.return.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Return List</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <span class="menu-text">Approvals</span><span class="menu-desc"></span>
                            <i class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-classic menu-submenu-left">
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('export_so')); ?>" class="menu-link bg-warning">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Export SO</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('export_so')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">SO - Domestic</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('po_fabric_purchase')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">PO - Fabric Purchase</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('po_fabric_purchase_jw')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">PO - Fabric Processing JW</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('po_fabric_purchase_jw')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">PO Yarn</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <span class="menu-text">Yarn Master</span><span class="menu-desc"></span>
                            <i class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-classic menu-submenu-left">
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('count.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Count</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('ply.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Ply</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('uom.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Uom</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('mill.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Mill Master</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('variety.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Variety</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('yarn_type.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Type</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('filaments.index')); ?>" class="menu-link bg-warning">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Filaments</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('tpms.index')); ?>" class="menu-link bg-warning">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">TPM</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('blends.index')); ?>" class="menu-link bg-warning">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Blends</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('yarn.index')); ?>" class="menu-link bg-warning">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Master</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <span class="menu-text">Stock</span><span class="menu-desc"></span>
                            <i class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-classic menu-submenu-left">
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('stock.yarn_inward.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Inward</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('stock.fabric_inward.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Fabric Inward</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('stock.yarn_opening_balance.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn Opening Balance</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('stock.fabric_opening_balance.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Fabric Opening Balance</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <span class="menu-text">Purchase</span><span class="menu-desc"></span>
                            <i class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-classic menu-submenu-left">
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('purchase.yarn_po.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Yarn PO</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('purchase.fabric_po.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Fabric PO</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <span class="menu-text">Sort Master</span><span class="menu-desc"></span>
                            <i class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-classic menu-submenu-left">
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('loom_types.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Loom Type</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('selvedge.index')); ?>" class="menu-link">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Selvedge Master</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('weave.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Weave</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('paper_tube_sizes.index')); ?>" class="menu-link bg-warning">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Paper Tube Size</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('sort.index')); ?>" class="menu-link bg-warning">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Sort Master</span>
                                    </a>
                                </li>

                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                            </ul>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true"><a href="javascript:;" class="menu-link menu-toggle"><span
                                class="menu-text">Planning</span><span class="menu-desc"></span><i
                                class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-fixed menu-submenu-right" style="width: 500px">
                            <div class="menu-subnav">
                                <ul class="menu-content">
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.orders')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Orders List</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.jobwork_weaving_contract.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Jobwork Weaving Contract</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.jobwork_weaving_weft_issue.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Jobwork Weaving Weft Issue</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.jobwork_process_contract.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Jobwork Process Contract</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.jobwork_process_contract_issue.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Jobwork Process Contract Issue</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.jobwork_finished_fabric_receive.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Jobwork Finished Fabric Receive</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.beam_receive_from_weaver.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Beam Receive from Weaver</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.sizing_plan.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Sizing Plan</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.sizing_yarn_issue')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Sizing Yarn Issue</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.beam_inward')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Beam Inward</span></a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.beam_outward')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Beam Outward</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.yarn_processing_contract.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn Processing Contract List</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.yarn_processing_contract_issue.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn Processing Contract IssuesList</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.yarn_processing_receive.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn Processing Contract Receive List</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('planning.yarn_processing_return.index')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn Process Return List</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true">
                        <a href="javascript:;" class="menu-link menu-toggle">
                            <span class="menu-text">Warehouse</span><span class="menu-desc"></span>
                            <i class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-classic menu-submenu-left">
                            <ul class="menu-subnav">
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('packing.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Packing Type</span>
                                    </a>
                                </li>
                                
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('warehouse.jobwork_fabric_receive.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Jobwork Fabric Receive</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('warehouse.bale_packing')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Bale Packing</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="#" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Cloth Challan</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="#" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Piece Join</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('warehouse.sale_return.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Sales Return</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('warehouse.process_return.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Process Return</span>
                                    </a>
                                </li>
                                <li class="menu-item" aria-haspopup="true">
                                    <a href="<?php echo e(route('warehouse.purchase_return.index')); ?>" class="menu-link ">
                                        <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                            class="menu-text">Purchase Return</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true"><a href="javascript:;" class="menu-link menu-toggle"><span
                                class="menu-text">Others</span><span class="menu-desc"></span><i
                                class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-fixed menu-submenu-right" style="width: 500px">
                            <div class="menu-subnav">
                                <ul class="menu-content">
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('inspection.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Inspection List</span>
                                                </a>
                                            </li>
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('delivery_terms.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Delivery Terms</span></a>
                                            </li>
                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('vendors.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Country</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('cities.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">City</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('states.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">State</span>
                                                </a>
                                            </li>

                                            
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Party to Location</span>
                                                </a>
                                            </li>

                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Roll / Bale Print Page</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('agents.index')); ?>"
                                                   class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Agents</span></a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('customers.index')); ?>"
                                                   class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Customer</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('sourcing_executives.index')); ?>"
                                                   class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Sourcing Executives</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('weave_factors.index')); ?>"
                                                   class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Weave Factors</span>
                                                </a>
                                            </li>
                                            <li class="menu-item" aria-haspopup="true">
                                                <a href="<?php echo e(route('costings.index')); ?>"
                                                   class="menu-link bg-warning">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Costing</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="hover"
                        aria-haspopup="true"><a href="javascript:;" class="menu-link menu-toggle"><span
                                class="menu-text">Reports</span><span class="menu-desc"></span><i
                                class="menu-arrow"></i></a>
                        <div class="menu-submenu menu-submenu-fixed menu-submenu-right" style="width: 1325px">
                            <div class="menu-subnav">
                                <ul class="menu-content">
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('warehouse_stock')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Warehouse Stock</span>
                                                </a>
                                            </li>
                                            
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('beam_inward')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Beam Inward</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('beam_inward_against_job_contract')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Beam Inward against Job Contract</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('vendors.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Focused Benefit</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('export_outstanding')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Export Outstanding</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('export_outstanding_new')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Export Outstanding New</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('weft_req_report')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Weft Requirement</span></a>
                                            </li>
                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('piece_bale_stock')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Piece & Bale Stock</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('piece_join')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Piece Join</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('weft_issue_report')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Weft Issue</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('yarn_to_sizing_register')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn to Sizing Register</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('stock_inward_yarn')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Stock Inward Yarn</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('opening_closing_balance')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn Opening & Closing Balance</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('sizing_reconciliation')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Sizing Reconcilation</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('inventory_fabric')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Inventory Fabric</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Quality wise Inventory Fabric</span>
                                                </a>
                                            </li>

                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Rewinding Issue to Trading</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('stock_inward_yarn_graph')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Stock Inward Yarn Graph</span>
                                                </a>
                                            </li>

                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('quality_fabric_outward')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Quality wise Fabric Outward</span>
                                                </a>
                                            </li>

                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('location_wise_yarn_stock')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Location wise Yarn Stock</span>
                                                </a>
                                            </li>
                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Approval Dashboard</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('domestic_order_status')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Domestic Order Status (Greige)</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('export_sales_order_status')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Export Order Status (Greige)</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('domestic_order_status_finished')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Domestic Order Status (Finished)</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('export_sales_order_status_finished')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Export Order Status (Finished)</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('fabric_po_status_purchase')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Fabric PO Status (Purchase)</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('fabric_po_status_jobwork')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Fabric PO Status (Jobwork)</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('jobwork_fabric_inward')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Jobwork Fabric Inward</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('purchase_fabric_inward')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Purchase Fabric Inward</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('packed_fabric_pending_for_dispatch')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Packing ready for Dispatch</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('fabric_obcb')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Fabric OBCB</span>
                                                </a>
                                            </li>

                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('yarn_entry_in_out')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Count entry wise in - out</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('so_status')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">SO Status</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">SO OS</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('yarn_po_status')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn PO Status</span>
                                                </a>
                                            </li>

                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Piecewise Dispatch Details</span>
                                                </a>
                                            </li>

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Piecewise Available Details</span>
                                                </a>
                                            </li>
                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Fabric In Out</span>
                                                </a>
                                            </li>

                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('yarn_invoice_report')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Yarn Invoice</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="menu-item">
                                        <ul class="menu-inner">
                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('gst.index')); ?>" class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Sizing Reconcilation</span>
                                                </a>
                                            </li>

                                            

                                            <li class="menu-item " aria-haspopup="true">
                                                <a href="<?php echo e(route('location_wise_yarn_stock')); ?>"
                                                   class="menu-link ">
                                                    <i class="menu-bullet menu-bullet-dot"><span></span></i><span
                                                        class="menu-text">Location wise Yarn Stock</span>
                                                </a>
                                            </li>

                                        
                                    </li>

                                    
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
                <!--end::Header Nav-->
            </div>
            <!--end::Header Menu-->
        </div>
        <!--end::Header Menu Wrapper-->
        <!--begin::Topbar-->
        <div class="topbar">
            <!--begin::User-->
            <div class="topbar-item">
                <div class="btn btn-icon w-auto btn-clean d-flex align-items-center btn-lg px-2"
                     id="kt_quick_user_toggle">
                    <span class="text-muted font-weight-bold font-size-base d-none d-md-inline mr-1">Hi,</span>
                    <span class="text-dark-50 font-weight-bolder font-size-base d-none d-md-inline mr-3">
                        
                    </span>
                    <span class="symbol symbol-35 symbol-light-warning">
                        <span class="symbol-label font-size-h5 font-weight-bold">
                            
                        </span>
                    </span>
                </div>
            </div>
            <!--end::User-->
        </div>
        <!--end::Topbar-->
    </div>
    <!--end::Container-->
</div>
<!--end::Header-->
<?php /**PATH D:\xampp\htdocs\erp_new-main\resources\views/header.blade.php ENDPATH**/ ?>
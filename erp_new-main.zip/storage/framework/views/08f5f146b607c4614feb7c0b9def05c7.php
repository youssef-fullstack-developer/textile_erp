<?php $__env->startSection('content'); ?>
    <div class="card card-custom" style="box-shadow: none">
        <div class="card-header flex-wrap border-0 pt-0 pb-0">
            <div class="card-title">
                <h3 class="card-label">
                    Export SO List
                </h3>
            </div>
        </div>
        <hr>
        <div class="ml-10">
            <a class="btn <?php if(empty($type) && $type !== '0'): ?> btn-linkedin <?php else: ?> btn-outline-info <?php endif; ?>"
               href="<?php echo e(route('export_so')); ?>" role="button">Pending</a>
            <a class="btn <?php if(!empty($type) && $type == 1): ?> btn-linkedin <?php else: ?> btn-outline-info <?php endif; ?>"
               href="<?php echo e(route('export_so',1)); ?>" role="button">Approved</a>
            <a class="btn <?php if(empty($type) && $type == '0'): ?> btn-linkedin <?php else: ?> btn-outline-info <?php endif; ?>"
               href="<?php echo e(route('export_so',0)); ?>" role="button">On Hold</a>
            <a class="btn <?php if(!empty($type) && $type == -1): ?> btn-linkedin <?php else: ?> btn-outline-info <?php endif; ?>"
               href="<?php echo e(route('export_so',-1)); ?>" role="button">Rejected</a>
        </div>
        <div class="card-body pt-2">
            <table class="table table-bordered table-hover" id="table_invoice_settings">
                <thead>
                <tr class="text-uppercase">
                    <th>SL NO</th>
                    <th class="pl-7"><span class="text-dark-75">SO Date</span></th>
                    <th class="pl-7"><span class="text-dark-75">SO No</span></th>
                    <th class="pl-7"><span class="text-dark-75">Buyer Name</span></th>
                    <th class="pl-7"><span class="text-dark-75">Sort Number.</span></th>
                    <th class="pl-7"><span class="text-dark-75">Quality</span></th>
                    <th class="pl-7"><span class="text-dark-75">Order Quantity</span></th>
                    <th class="pl-7"><span class="text-dark-75">Delivery Date</span></th>
                    <th class="pl-7"><span class="text-dark-75">Action</span></th>
                </tr>
                </thead>
                <tbody>
                <?php if(!empty($list)): ?>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item->sales_order?->order_date); ?></td>
                            <td><?php echo e($item->sales_order?->order_no); ?></td>
                            <td><?php echo e($item->sales_order?->buyer?->name); ?></td>
                            <td><?php echo e($item->quality?->sort_no); ?></td>
                            <td><?php echo e($item->quality?->sort_no); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e($item->sales_order_sub_details()?->first()?->ex_factory_date); ?></td>
                            <td class="d-flex">
                                <a href="<?php echo e(route('export_so_actions.edit', $item->id)); ?>"
                                   class="btn btn-outline-info btn-sm btn-clean  " title="Edit details">
                                    Select
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="assets/custom/datatables/datatables.bundle.js"></script>
    <script src="assets/js/datatables/invoice_settings.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\erp_new-main\resources\views/approvals/export_so/index.blade.php ENDPATH**/ ?>
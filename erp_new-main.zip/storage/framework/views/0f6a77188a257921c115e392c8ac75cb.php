<?php $__env->startSection('content'); ?>
    <?php
        if(empty($item)){
            $item = NULL;
        }
        $action = $item?->id > 0 ? '/sales_order/'.$item?->id : '/sales_order' ;
    ?>
    <?php echo e(html()->form('POST', $action)->open()); ?>

    <?php if($item?->id > 0): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-custom ">
                <div class="card-header">
                    <div class="card-title">
                        <h3 class="card-label">
                            <?php echo e($item?->id > 0 ? 'Edit' : 'Add'); ?> Sales Order
                        </h3>
                    </div>
                    <div class="card-toolbar">
                        <a href="<?php echo e(route('sales_order.index')); ?>"
                           class="btn btn-light-primary font-weight-bolder mr-2">
                            <i class="ki ki-long-arrow-back icon-sm"></i>
                            Back
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Invoice Type:</label>
                            <select name="invoice_type_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $invoice_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->invoice_type_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Contract Type:</label>
                            <select name="contract_type_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $contract_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->contract_type_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Order Route:</label>
                            <select name="city_id" class="form-control">
                                <option value="">Select Order Route</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->city_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Order Date:</label>
                            <input type="date" name="order_date" class="form-control" autocomplete="off"
                                   placeholder="Enter Order Date"
                                   value="<?php echo e($item ? $item?->order_date : old('address')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>PO No:</label>
                            <input type="text" name="po_no" class="form-control" autocomplete="off"
                                   placeholder="" value=" <?php echo e($item ? $item?->po_no : old('po_no')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>PO Date:</label>
                            <input type="date" name="po_date" class="form-control" autocomplete="off"
                                   placeholder="Enter" value="<?php echo e($item ? $item?->po_date : old('po_date')); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Buyer Name:</label>
                            <select name="buyer_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->buyer_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-8">
                            <label>Address:</label>
                            <input type="text" name="adress" class="form-control" autocomplete="off"
                                   placeholder="Enter Address" value="<?php echo e($item ? $item?->adress : old('adress')); ?>"/>
                        </div>

                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Sourcing Executive:</label>
                            <select name="sourcing_executive_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $sourcing_executives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->sourcing_executive_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Ship To:</label>
                            <select name="ship_to_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->ship_to_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Ship to Address:</label>
                            <input type="text" name="ship_adress" class="form-control"
                                   autocomplete="off" placeholder="Enter Ship to Address"
                                   value="<?php echo e($item ? $item?->ship_adress : old('ship_adress')); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Tax ID No.:</label>
                            <input type="text" name="tax_id" class="form-control" autocomplete="off"
                                   placeholder="Enter Tax ID No." value="<?php echo e($item ? $item?->tax_id : old('tax_id')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Sales Contract No.:</label>
                            <input type="text" name="sale_contract_no" class="form-control"
                                   autocomplete="off" placeholder="Enter Sales Contract No."
                                   value="<?php echo e($item ? $item?->sale_contract_no : old('sale_contract_no')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Agent / Broker:</label>
                            <select name="agent_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->agent_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Agent Percent:</label>
                            <input type="number" name="agent_percent" class="form-control"
                                   autocomplete="off" placeholder="Enter Agent Percent"
                                   value="<?php echo e($item ? $item?->agent_percent : old('agent_percent')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Port of Loading:</label>
                            <input type="text" name="port_loading" class="form-control"
                                   autocomplete="off" placeholder="Enter Port of Loading"
                                   value="<?php echo e($item ? $item?->port_loading : old('port_loading')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Port of Destination:</label>
                            <input type="text" name="port_destination" class="form-control"
                                   autocomplete="off" placeholder="Enter Port of Destination"
                                   value="<?php echo e($item ? $item?->port_destination : old('port_destination')); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Insurance:</label>
                            <input type="text" name="insurance" class="form-control" autocomplete="off"
                                   placeholder="Enter Insurance"
                                   value="<?php echo e($item ? $item?->insurance : old('insurance')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Shipping Method:</label>
                            <select name="shipping_method" class="form-control">
                                <option value="">Select</option>
                                <option
                                    value="sea" <?php echo e(($item?->shipping_method == 'sea') ? 'selected' : ''); ?>>
                                    SEA
                                </option>
                                <option value="air" <?php echo e(($item?->shipping_method == 'air') ? 'selected' : ''); ?>>
                                    AIR
                                </option>
                                <option value="road" <?php echo e(($item?->shipping_method == 'road') ? 'selected' : ''); ?>>
                                    BY ROAD
                                </option>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Shipping Terms:</label>
                            <select name="shipping_terms_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $shipping_terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->shipping_terms_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Shipping Terms Detail:</label>
                            <input type="text" name="shipping_terms_det" class="form-control"
                                   autocomplete="off" placeholder="Enter Shipping Terms Detail"
                                   value="<?php echo e($item ? $item?->shipping_terms_det : old('shipping_terms_det')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Bank:</label>
                            <select name="bank_id" class="form-control">
                                <option value="">Select Bank</option>
                                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->bank_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Container Size:</label>
                            <select name="container_size_id" class="form-control">
                                <option value="">Select Container Size</option>
                                <?php $__currentLoopData = $container_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->container_size_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Payment Terms:</label>
                            <select name="payment_terms_id" class="form-control">
                                <option value="">Select Payment Terms</option>
                                <?php $__currentLoopData = $payment_terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->payment_terms_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <div class="col-4">
                            <label>Terms & Conditions:</label>
                            <select name="terms_conditions_id" class="form-control">
                                <option value="">Select Terms & Conditions</option>
                                <?php $__currentLoopData = $terms_conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->terms_conditions_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>User:</label>
                            <select name="user_id" class="form-control">
                                <option value="">Select User</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->user_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Confirmation Date *</label>
                            <input type="date" name="confirmation_date" class="form-control"
                                   autocomplete="off" placeholder=""
                                   value="<?php echo e($item ? $item?->confirmation_date : old('confirmation_date')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>Sales Co-Ordinator*</label>
                            <select name="sales_co_ordinator_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $sales_co_ordinators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->sales_co_ordinator_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-4">
                            <label>SO Type*</label>
                            <select name="so_type_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $so_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->so_type_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Remark</label>
                            <input type="text" name="remark" class="form-control" autocomplete="off"
                                   placeholder="" value="<?php echo e($item ? $item?->remark : old('remark')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>PI Date</label>
                            <input type="date" name="pi_date" class="form-control" autocomplete="off"
                                   placeholder=""
                                   value="<?php echo e($item ? $item?->pi_date : old('pi_date')); ?>"/>
                        </div>
                    </div>
                    
                    <h2 class="text-center">Order Details</h2>
                    <div id="order_details">
                        <?php ($i = 0); ?>
                        <?php while( (empty($item) &&  $i == 0) || (count($item?->sales_order_details ?? []) > $i ) ): ?>
                            <?php ($detail = $item ? $item->sales_order_details[$i] : NULL); ?>
                            <div class="form-group border p-3 border-dark border-2 tr">
                                <input type="hidden" name="order_details[<?php echo e($i); ?>][sales_order_detail_id][]"
                                       value="<?php echo e($detail ? $detail?->id : ''); ?>">
                                <div class="form-group row">
                                    <div class="col-12">
                                        <div class="col-12 text-right">
                                            <button
                                                class="btn btn-icon btn-primary btn-sm btn-circle mr-2 btn_add_order_details"
                                                type="button" onclick="add_order_details()"><i class="fa fa-plus"></i>
                                            </button>
                                            <button class="btn btn-icon btn-danger btn-sm btn-circle " type="button"
                                                    onclick="deleteRow(this)"><i class="fa fa-trash"></i></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-4">
                                        <label>Fabric Type<b class="text-danger">*</b></label>
                                        <select name="order_details[<?php echo e($i); ?>][fabric_type]" class="form-control">
                                            <option value="">Select</option>
                                            <option
                                                value="finished" <?php echo e(($detail?->fabric_type == 'finished') ? 'selected' : ''); ?>>
                                                Finished
                                            </option>
                                            <option
                                                value="grey" <?php echo e(($detail?->fabric_type == 'grey') ? 'selected' : ''); ?>>
                                                Grey
                                            </option>
                                        </select>
                                    </div>
                                    <div class="col-4">
                                        <label>Finished Quality<b class="text-danger">*</b></label>
                                        <select name="order_details[<?php echo e($i); ?>][finished_quality_id]" class="form-control"
                                                required>
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($row->id); ?>" <?php echo e(($detail?->finished_quality_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->sort_no); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-4">
                                        <label>WeaveType<b class="text-danger">*</b></label>
                                        <select name="order_details[<?php echo e($i); ?>][weave_type_id]" class="form-control"
                                                required>
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $weave_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($row->id); ?>" <?php echo e(($detail?->weave_type_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-4">
                                        <label><?php echo e($i + 1); ?> Quality<b class="text-danger">*</b></label>
                                        <select name="order_details[<?php echo e($i); ?>][first_quality_id]" class="form-control"
                                                required>
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($row->id); ?>" <?php echo e(($detail?->first_quality_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->sort_no); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-4">
                                        <label>Sort Code</label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][sort_code]"
                                               class="form-control" autocomplete="off" readonly placeholder=""
                                               value="<?php echo e($detail ? $detail?->sort_code : old('sort_code')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Selvedge</label>
                                        <select name="order_details[<?php echo e($i); ?>][selvedge_id]" class="form-control">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $selvedges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($row->id); ?>" <?php echo e(($detail?->selvedge_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-8">
                                        <label>Description</label>
                                        <textarea name="order_details[<?php echo e($i); ?>][description]"
                                                  class="form-control" autocomplete="off" rows="1"
                                        ><?php echo e($detail ? $detail?->description : old('description')); ?></textarea>
                                    </div>
                                    <div class="col-4">
                                        <label>HSN Code</label>
                                        <input type="text" name="order_details[<?php echo e($i); ?>][hsn_code]"
                                               class="form-control" autocomplete="off"
                                               placeholder=""
                                               value="<?php echo e($detail ? $detail?->hsn_code : old('hsn_code')); ?>"/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-4">
                                        <label>Quantity <b class="text-danger">*</b></label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][quantity]"
                                               class="form-control" autocomplete="off" placeholder="" required
                                               value="<?php echo e($detail ? $detail?->quantity : old('quantity')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Unit<b class="text-danger">*</b></label>
                                        <select name="order_details[<?php echo e($i); ?>][unit_id]" class="form-control" required>
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($row->id); ?>" <?php echo e(($detail?->unit_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-4">
                                        <label>Currency<b class="text-danger">*</b></label>
                                        <select name="order_details[<?php echo e($i); ?>][currency]" class="form-control"
                                                required>
                                            <option value="">Select</option>
                                            <option
                                                value="usd" <?php echo e(($detail?->currency == 'usd') ? 'selected' : ''); ?>>
                                                USD
                                            </option>
                                            <option
                                                value="rupees" <?php echo e(($detail?->currency == 'rupees') ? 'selected' : ''); ?>>
                                                RUPEES
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-4">
                                        <label>Rate Per Unit<b class="text-danger">*</b></label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][rate_per_unit]"
                                               class="form-control" autocomplete="off" required
                                               value="<?php echo e($detail ? $detail?->rate_per_unit : old('rate_per_unit')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Value<b class="text-danger">*</b></label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][val]"
                                               class="form-control" autocomplete="off" placeholder="" required
                                               value="<?php echo e($detail ? $detail?->val : old('val')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Exchange Rate<b class="text-danger">*</b></label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][exchange_rate]"
                                               class="form-control" autocomplete="off" placeholder="" required
                                               value="<?php echo e($detail ? $detail?->exchange_rate : old('exchange_rate')); ?>"/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-4">
                                        <label>INR Rate(In Mtrs)<b class="text-danger">*</b></label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][inr_rate]"
                                               class="form-control" autocomplete="off" required
                                               value="<?php echo e($detail ? $detail?->inr_rate : old('inr_rate')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Yarn Details</label>
                                        <input type="text" name="order_details[<?php echo e($i); ?>][yarn_det]"
                                               class="form-control" autocomplete="off" placeholder=""
                                               value="<?php echo e($detail ? $detail?->yarn_det : old('yarn_det')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Buyer Sort<b class="text-danger">*</b></label>
                                        <input type="text" name="order_details[<?php echo e($i); ?>][buyer_sort]"
                                               class="form-control" autocomplete="off" placeholder="" required
                                               value="<?php echo e($detail ? $detail?->buyer_sort : old('buyer_sort')); ?>"/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-4">
                                        <label>Piece Length</label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][piece_length]"
                                               class="form-control" autocomplete="off"
                                               value="<?php echo e($detail ? $detail?->piece_length : old('piece_length')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Inspection Type<b class="text-danger">*</b></label>
                                        <select name="order_details[<?php echo e($i); ?>][inspection_type_id]" class="form-control">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $inspection_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($row->id); ?>" <?php echo e(($detail?->inspection_type_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-4">
                                        <label>Packing Type</label>
                                        <select name="order_details[<?php echo e($i); ?>][packing_type]" class="form-control">
                                            <option value="">Select</option>
                                            <option
                                                value="roll" <?php echo e(($detail?->packing_type == 'usd') ? 'selected' : ''); ?>>
                                                ROLL
                                            </option>
                                            <option
                                                value="bale" <?php echo e(($detail?->packing_type == 'rupees') ? 'selected' : ''); ?>>
                                                BALE
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-4">
                                        <label>Variation %</label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][variation]"
                                               class="form-control"
                                               autocomplete="off"
                                               value="<?php echo e($detail ? $detail?->variation : old('variation')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Paper Tube Size</label>
                                        <select name="order_details[<?php echo e($i); ?>][paper_tube_size_id]" class="form-control">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $paper_tube_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($row->id); ?>" <?php echo e(($detail?->paper_tube_size_id == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-4">
                                        <label>Fold</label>
                                        <input type="text" name="order_details[<?php echo e($i); ?>][fold]" class="form-control"
                                               autocomplete="off" placeholder=""
                                               value="<?php echo e($detail ? $detail?->fold : old('pi_date')); ?>"/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-4">
                                        <label>Frieght Charge</label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][frieght_charge]"
                                               class="form-control" autocomplete="off"
                                               value="<?php echo e($detail ? $detail?->frieght_charge : old('frieght_charge')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Surcharge</label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][surcharge]"
                                               class="form-control" autocomplete="off" placeholder=""
                                               value="<?php echo e($detail ? $detail?->surcharge : old('surcharge')); ?>"/>
                                    </div>
                                    <div class="col-4">
                                        <label>Instruction For Factory<b class="text-danger">*</b></label>
                                        <textarea name="order_details[<?php echo e($i); ?>][instruction_factory]"
                                                  class="form-control" autocomplete="off" rows="1" required
                                        ><?php echo e($detail ? $detail?->instruction_factory : old('instruction_factory')); ?> </textarea>
                                    </div>
                                </div>
                                
                                <div id="order_sub_details_<?php echo e($i); ?>">
                                    <?php ($l = 0); ?>
                                    <?php while( (empty($detail) &&  $l == 0) || (count($detail?->sales_order_sub_details ?? []) > $l ) ): ?>
                                        <?php ($_sub_detail = $detail ? $detail->sales_order_sub_details[$l] : NULL); ?>
                                        <div class="form-group border p-3 m-3 border-dark border-2 tr">
                                            <input type="hidden"
                                                   name="order_details[<?php echo e($i); ?>][sales_order_sub_detail_id][]"
                                                   value="<?php echo e($_sub_detail ? $_sub_detail?->id : ''); ?>">
                                            <div class="form-group row">
                                                <div class="col-4">
                                                    <label><?php echo e(($l + 1)); ?> FCL (Qty)</label>
                                                    <input type="number" name="order_details[<?php echo e($i); ?>][fcl][]"
                                                           class="form-control" autocomplete="off"
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->fcl : old('fcl')); ?>"/>
                                                </div>
                                                <div class="col-4">
                                                    <label>PO LDS</label>
                                                    <input type="date" name="order_details[<?php echo e($i); ?>][po_lds][]"
                                                           class="form-control" autocomplete="off" placeholder=""
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->po_lds : old('po_lds')); ?>"/>
                                                </div>
                                                <div class="col-4 text-right">
                                                    <button
                                                        class="btn btn-icon btn-primary btn-sm btn-circle mr-2 btn_add_order_sub_details_<?php echo e($i); ?>"
                                                        type="button" onclick="add_order_sub_details(<?php echo e($i); ?>)"><i
                                                            class="fa fa-plus"></i>
                                                    </button>
                                                    <button class="btn btn-icon btn-danger btn-sm btn-circle "
                                                            type="button"
                                                            onclick="deleteRow(this)"><i class="fa fa-trash"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-4">
                                                    <label>Ex-factory Dt<b class="text-danger">*</b></label>
                                                    <input type="date" name="order_details[<?php echo e($i); ?>][ex_factory_date][]"
                                                           class="form-control" required
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->ex_factory_date : old('ex_factory_date')); ?>"/>
                                                </div>
                                                <div class="col-4">
                                                    <label>Actual Ex-Factory Dt</label>
                                                    <input type="date"
                                                           name="order_details[<?php echo e($i); ?>][actual_ex_factory_date][]"
                                                           class="form-control" autocomplete="off"
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->actual_ex_factory_date : old('actual_ex_factory_date')); ?>"/>
                                                </div>
                                                <div class="col-4">
                                                    <label>LC Expire date</label>
                                                    <input type="date" name="order_details[<?php echo e($i); ?>][lc_expire_date][]"
                                                           class="form-control" autocomplete="off"
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->lc_expire_date : old('lc_expire_date')); ?>"/>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-4">
                                                    <label>Office Remark</label>
                                                    <input type="text" name="order_details[<?php echo e($i); ?>][office_remark][]"
                                                           class="form-control" autocomplete="off"
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->office_remark : old('office_remark')); ?>"/>
                                                </div>
                                                <div class="col-8">
                                                    <label>Factory Remark</label>
                                                    <textarea name="order_details[<?php echo e($i); ?>][factory_remark][]"
                                                              class="form-control" rows="1" autocomplete="off"
                                                    ><?php echo e($_sub_detail ? $_sub_detail?->factory_remark : old('factory_remark')); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-4">
                                                    <label>LC No</label>
                                                    <input type="number" name="order_details[<?php echo e($i); ?>][lc_no][]"
                                                           class="form-control" autocomplete="off"
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->lc_no : old('lc_no')); ?>"/>
                                                </div>
                                                <div class="col-4">
                                                    <label>LDS Date</label>
                                                    <input type="date" name="order_details[<?php echo e($i); ?>][lds_date][]"
                                                           class="form-control" autocomplete="off"
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->lds_date : old('lds_date')); ?>"/>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-4">
                                                    <label>Line</label>
                                                    <input type="text" name="order_details[<?php echo e($i); ?>][line][]"
                                                           class="form-control" autocomplete="off" placeholder=""
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->line : old('line')); ?>"/>
                                                </div>
                                                <div class="col-4">
                                                    <label>ETD</label>
                                                    <input type="date" name="order_details[<?php echo e($i); ?>][etd][]"
                                                           class="form-control" autocomplete="off"
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->etd : old('etd')); ?>"/>
                                                </div>
                                                <div class="col-4">
                                                    <label>ETA</label>
                                                    <input type="date" name="order_details[<?php echo e($i); ?>][eta][]"
                                                           class="form-control" autocomplete="off"
                                                           value="<?php echo e($_sub_detail ? $_sub_detail?->eta : old('eta')); ?>"/>
                                                </div>
                                            </div>

                                        </div>

                                        <?php ($l++); ?>
                                    <?php endwhile; ?>
                                </div>
                                
                                <div class="form-group row">
                                    <div class="col-4">
                                        <table
                                            class="table table-head-noborder table-active table-responsive-sm loading-table table-foot-bg">
                                            <thead>
                                            <tr>
                                                <th>YARN CERTIFICATION TYPE</th>
                                                <th style="width:100px;">ADD/DELETE</th>
                                            </tr>
                                            </thead>
                                            <tbody id="tbl_yarn_certification_types">
                                            <?php ($j = 0); ?>
                                            <?php while( (empty($detail) &&  $j == 0) || (count($detail?->yarn_certification_types ?? []) > $j ) ): ?>
                                                <?php ($line = $detail ? $detail->yarn_certification_types[$j] : NULL); ?>
                                                <tr class="tr">
                                                    <td style="vertical-align: middle">
                                                        <select
                                                            name="order_details[<?php echo e($i); ?>][yarn_certification_type_id][]"
                                                            class="form-control">
                                                            <option value="">Select</option>
                                                            <?php $__currentLoopData = $yarn_certification_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option
                                                                    value="<?php echo e($yarn->id); ?>" <?php echo e(($line?->yarn_certification_type_id == $yarn->id) ? 'selected' : ''); ?>><?php echo e($yarn->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <button
                                                            class="btn btn-icon btn-sm btn-primary btn-circle"
                                                            type="button" onclick="add_yarn_certification_type(<?php echo e($i); ?>)">
                                                            <i
                                                                class="fa fa-plus"></i></button>
                                                        <button class="btn btn-icon btn-danger btn-sm btn-circle"
                                                                type="button"
                                                                onclick="deleteRow(this)"><i class="fa fa-trash"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                                <?php ($j++); ?>
                                            <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="col-4">
                                        <label>Costing Number</label>
                                        <input type="number" name="order_details[<?php echo e($i); ?>][costing_number]"
                                               class="form-control" autocomplete="off"
                                               value="<?php echo e($detail ? $detail?->costing_number : old('costing_number')); ?>"/>
                                    </div>
                                </div>

                            </div>
                            <?php ($i++); ?>
                        <?php endwhile; ?>
                    </div>
                    

                </div>
                <div class="card-footer">
                    <button type="submit" name="submit" value="submit" class="btn btn-primary font-weight-bolder">
                        <i class="ki ki-check icon-sm"></i>
                        Submit
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php echo e(html()->form()->close()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        const add_yarn_certification_type = (id) => {
            var html = '';
            html += `<tr class="tr">`;
            html += `    <td style="vertical-align: middle">`;
            html += `        <select name="order_details[${id}][yarn_certification_type_id][]"`;
            html += `                class="form-control">`;
            html += `            <option value="">Select</option>`;
            <?php $__currentLoopData = $yarn_certification_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                html += `            <option`;
            html += `                value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>`;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                html += `        </select>`;
            html += `    </td>`;
            html += `    <td>`;
            html += `        <button`;
            html += `            class="btn btn-icon btn-sm btn-primary btn-circle"`;
            html += `            type="button" onclick="add_yarn_certification_type(${id})"><i`;
            html += `            class="fa fa-plus"></i></button>`;
            html += `        <button class="btn btn-icon btn-danger btn-sm btn-circle" type="button"`;
            html += `                onclick="deleteRow(this)"><i class="fa fa-trash"></i></button>`;
            html += `    </td>`;
            html += `</tr>`;
            $('#tbl_yarn_certification_types').append(html);
        };
        const add_order_sub_details = (index) => {
            var count = $(".btn_add_order_sub_details_"+index).length;
            var html = '';
            html += `<div class="form-group border p-3 m-3 border-dark border-2 tr">`;
            html += `    <input type="hidden" name="order_details[${index}][sales_order_sub_detail_id][]">`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += '                <label>' + (count + 1) + ' FCL (Qty)</label>';
            html += `                <input type="number" name="order_details[${index}][fcl][]"`;
            html += `                       class="form-control" autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>PO LDS</label>`;
            html += `                <input type="date" name="order_details[${index}][po_lds][]" `;
            html += `                       class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4 text-right">`;
            html += `                <button`;
            html += `                    class="btn btn-icon btn-primary btn-sm btn-circle mr-2 btn_add_order_sub_details_${index}"`;
            html += `                    type="button" onclick="add_order_sub_details(${index})"><i class="fa fa-plus"></i>`;
            html += `                </button>`;
            html += `                <button class="btn btn-icon btn-danger btn-sm btn-circle " type="button"`;
            html += `                        onclick="deleteRow(this)"><i class="fa fa-trash"></i></button>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Ex-factory Dt<b class="text-danger">*</b></label>`;
            html += `                <input type="date" name="order_details[${index}][ex_factory_date][]"`;
            html += `                       class="form-control"  required/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Actual Ex-Factory Dt</label>`;
            html += `                <input type="date" name="order_details[${index}][actual_ex_factory_date][]"`;
            html += `                       class="form-control" autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>LC Expire date</label>`;
            html += `                <input type="date" name="order_details[${index}][lc_expire_date][]"`;
            html += `                       class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Office Remark</label>`;
            html += `                <input type="text" name="order_details[${index}][office_remark][]"`;
            html += `                       class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-8">`;
            html += `                <label>Factory Remark</label>`;
            html += `                <textarea name="order_details[${index}][factory_remark][]"`;
            html += `                          class="form-control"rows="1" autocomplete="off"></textarea>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>LC No</label>`;
            html += `                <input type="number" name="order_details[${index}][lc_no][]"`;
            html += `                       class="form-control" autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>LDS Date</label>`;
            html += `                <input type="date" name="order_details[${index}][lds_date][]"`;
            html += `                       class="form-control" autocomplete="off" />`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Line</label>`;
            html += `                <input type="text" name="order_details[${index}][line][]" class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>ETD</label>`;
            html += `                <input type="date" name="order_details[${index}][etd][]" class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>ETA</label>`;
            html += `                <input type="date" name="order_details[${index}][eta][]" class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `</div>`;
            $('#order_sub_details_' + index).append(html);
        };
        const add_order_details = () => {
            var count = $('.btn_add_order_details').length;
            var html = '';
            html += `<div class="form-group border p-3 border-dark border-2 tr">`;
            html += `    <input type="hidden" name="order_details[${count}][sales_order_detail_id][]" >`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-12">`;
            html += `                <div class="col-12 text-right">`;
            html += `                    <button`;
            html += `                        class="btn btn-icon btn-primary btn-sm btn-circle mr-2 btn_add_order_details"`;
            html += `                        type="button" onclick="add_order_details()"><i class="fa fa-plus"></i>`;
            html += `                    </button>`;
            html += `                    <button class="btn btn-icon btn-danger btn-sm btn-circle " type="button"`;
            html += `                            onclick="deleteRow(this)"><i class="fa fa-trash"></i></button>`;
            html += `                </div>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Fabric Type<b class="text-danger">*</b></label>`;
            html += `                <select name="order_details[${count}][fabric_type]" class="form-control">`;
            html += `                    <option value="">Select</option>`;
            html += `                    <option`;
            html += `                        value="finished" >`;
            html += `                        Finished`;
            html += `                    </option>`;
            html += `                    <option`;
            html += `                        value="grey" >`;
            html += `                        Grey`;
            html += `                    </option>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Finished Quality<b class="text-danger">*</b></label>`;
            html += `                <select name="order_details[${count}][finished_quality_id]" class="form-control"`;
            html += `                        required>`;
            html += `                    <option value="">Select</option>`;
            html += `                    <?php $__currentLoopData = $sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>`;
            html += `                    <option`;
            html += `                        value="<?php echo e($row->id); ?>" ><?php echo e($row->sort_no); ?></option>`;
            html += `                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>WeaveType<b class="text-danger">*</b></label>`;
            html += `                <select name="order_details[${count}][weave_type_id]" class="form-control"`;
            html += `                        required>`;
            html += `                    <option value="">Select</option>`;
            html += `                    <?php $__currentLoopData = $weave_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>`;
            html += `                    <option`;
            html += `                        value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>`;
            html += `                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>${count + 1} Quality<b class="text-danger">*</b></label>`;
            html += `                <select name="order_details[${count}][first_quality_id]" class="form-control"`;
            html += `                        required>`;
            html += `                    <option value="">Select</option>`;
            html += `                    <?php $__currentLoopData = $sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>`;
            html += `                    <option`;
            html += `                        value="<?php echo e($row->id); ?>" ><?php echo e($row->sort_no); ?></option>`;
            html += `                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Sort Code</label>`;
            html += `                <input type="number" name="order_details[${count}][sort_code]"`;
            html += `                       class="form-control" autocomplete="off" readonly placeholder="" />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Selvedge</label>`;
            html += `                <select name="order_details[${count}][selvedge_id]" class="form-control">`;
            html += `                    <option value="">Select</option>`;
            html += `                    <?php $__currentLoopData = $selvedges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>`;
            html += `                    <option`;
            html += `                        value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>`;
            html += `                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-8">`;
            html += `                <label>Description</label>`;
            html += `                <textarea name="order_details[${count}][description]"`;
            html += `                          class="form-control" autocomplete="off" rows="1" ></textarea>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>HSN Code</label>`;
            html += `                <input type="text" name="order_details[${count}][hsn_code]"`;
            html += `                       class="form-control" autocomplete="off" placeholder="" />`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Quantity <b class="text-danger">*</b></label>`;
            html += `                <input type="number" name="order_details[${count}][quantity]"`;
            html += `                       class="form-control" autocomplete="off" placeholder="" required />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Unit<b class="text-danger">*</b></label>`;
            html += `                <select name="order_details[${count}][unit_id]" class="form-control" required>`;
            html += `                    <option value="">Select</option>`;
            html += `                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>`;
            html += `                    <option`;
            html += `                        value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>`;
            html += `                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Currency<b class="text-danger">*</b></label>`;
            html += `                <select name="order_details[${count}][currency]" class="form-control"`;
            html += `                        required>`;
            html += `                    <option value="">Select</option>`;
            html += `                    <option`;
            html += `                        value="usd" >`;
            html += `                        USD`;
            html += `                    </option>`;
            html += `                    <option`;
            html += `                        value="rupees" >`;
            html += `                        RUPEES`;
            html += `                    </option>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Rate Per Unit<b class="text-danger">*</b></label>`;
            html += `                <input type="number" name="order_details[${count}][rate_per_unit]"`;
            html += `                       class="form-control" autocomplete="off" required />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Value<b class="text-danger">*</b></label>`;
            html += `                <input type="number" name="order_details[${count}][val]"`;
            html += `                       class="form-control" autocomplete="off" placeholder="" required />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Exchange Rate<b class="text-danger">*</b></label>`;
            html += `                <input type="number" name="order_details[${count}][exchange_rate]"`;
            html += `                       class="form-control" autocomplete="off" placeholder="" required />`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>INR Rate(In Mtrs)<b class="text-danger">*</b></label>`;
            html += `                <input type="number" name="order_details[${count}][inr_rate]"`;
            html += `                       class="form-control" autocomplete="off" required />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Yarn Details</label>`;
            html += `                <input type="text" name="order_details[${count}][yarn_det]"`;
            html += `                       class="form-control" autocomplete="off" placeholder="" />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Buyer Sort<b class="text-danger">*</b></label>`;
            html += `                <input type="text" name="order_details[${count}][buyer_sort]"`;
            html += `                       class="form-control" autocomplete="off" placeholder="" required />`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Piece Length</label>`;
            html += `                <input type="number" name="order_details[${count}][piece_length]"`;
            html += `                       class="form-control" autocomplete="off" />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Inspection Type<b class="text-danger">*</b></label>`;
            html += `                <select name="order_details[${count}][inspection_type_id]" class="form-control">`;
            html += `                    <option value="">Select</option>`;
            html += `                    <?php $__currentLoopData = $inspection_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>`;
            html += `                    <option`;
            html += `                        value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>`;
            html += `                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Packing Type</label>`;
            html += `                <select name="order_details[${count}][packing_type]" class="form-control">`;
            html += `                    <option value="">Select</option>`;
            html += `                    <option`;
            html += `                        value="roll" >`;
            html += `                        ROLL`;
            html += `                    </option>`;
            html += `                    <option`;
            html += `                        value="bale" >`;
            html += `                        BALE`;
            html += `                    </option>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Variation %</label>`;
            html += `                <input type="number" name="order_details[${count}][variation]"`;
            html += `                       class="form-control"`;
            html += `                       autocomplete="off" />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Paper Tube Size</label>`;
            html += `                <select name="order_details[${count}][paper_tube_size_id]" class="form-control">`;
            html += `                    <option value="">Select</option>`;
            html += `                    <?php $__currentLoopData = $paper_tube_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>`;
            html += `                    <option`;
            html += `                        value="<?php echo e($row->id); ?>" ><?php echo e($row->name); ?></option>`;
            html += `                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`;
            html += `                </select>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Fold</label>`;
            html += `                <input type="text" name="order_details[${count}][fold]" class="form-control"`;
            html += `                       autocomplete="off" placeholder="" />`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Frieght Charge</label>`;
            html += `                <input type="number" name="order_details[${count}][frieght_charge]"`;
            html += `                       class="form-control" autocomplete="off" />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Surcharge</label>`;
            html += `                <input type="number" name="order_details[${count}][surcharge]"`;
            html += `                       class="form-control" autocomplete="off" placeholder="" />`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Instruction For Factory<b class="text-danger">*</b></label>`;
            html += `                <textarea name="order_details[${count}][instruction_factory]"`;
            html += `                          class="form-control" autocomplete="off" rows="1" required`;
            html += `                ></textarea>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        `;
            html += `        <div id="order_sub_details_${count}">`;
            html += `<div class="form-group border p-3 m-3 border-dark border-2 tr">`;
            html += `    <input type="hidden" name="order_details[${count}][sales_order_sub_detail_id][]">`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += '                <label>1 FCL (Qty)</label>';
            html += `                <input type="number" name="order_details[${count}][fcl][]"`;
            html += `                       class="form-control" autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>PO LDS</label>`;
            html += `                <input type="date" name="order_details[${count}][po_lds][]" `;
            html += `                       class="form-control" autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4 text-right">`;
            html += `                <button`;
            html += `                    class="btn btn-icon btn-primary btn-sm btn-circle mr-2 btn_add_order_sub_details_${count}"`;
            html += `                    type="button" onclick="add_order_sub_details(${count})"><i class="fa fa-plus"></i>`;
            html += `                </button>`;
            html += `                <button class="btn btn-icon btn-danger btn-sm btn-circle " type="button"`;
            html += `                        onclick="deleteRow(this)"><i class="fa fa-trash"></i></button>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Ex-factory Dt<b class="text-danger">*</b></label>`;
            html += `                <input type="date" name="order_details[${count}][ex_factory_date][]"`;
            html += `                       class="form-control"  required/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>Actual Ex-Factory Dt</label>`;
            html += `                <input type="date" name="order_details[${count}][actual_ex_factory_date][]"`;
            html += `                       class="form-control" autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>LC Expire date</label>`;
            html += `                <input type="date" name="order_details[${count}][lc_expire_date][]"`;
            html += `                       class="form-control" autocomplete="off"/>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Office Remark</label>`;
            html += `                <input type="text" name="order_details[${count}][office_remark][]"`;
            html += `                       class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-8">`;
            html += `                <label>Factory Remark</label>`;
            html += `                <textarea name="order_details[${count}][factory_remark][]"`;
            html += `                          class="form-control"rows="1" autocomplete="off"></textarea>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>LC No</label>`;
            html += `                <input type="number" name="order_details[${count}][lc_no][]"`;
            html += `                       class="form-control" autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>LDS Date</label>`;
            html += `                <input type="date" name="order_details[${count}][lds_date][]"`;
            html += `                       class="form-control" autocomplete="off" />`;
            html += `            </div>`;
            html += `        </div>`;
            html += `        <div class="form-group row">`;
            html += `            <div class="col-4">`;
            html += `                <label>Line</label>`;
            html += `                <input type="text" name="order_details[${count}][line][]" class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>ETD</label>`;
            html += `                <input type="date" name="order_details[${count}][etd][]" class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `            <div class="col-4">`;
            html += `                <label>ETA</label>`;
            html += `                <input type="date" name="order_details[${count}][eta][]" class="form-control"`;
            html += `                       autocomplete="off"/>`;
            html += `            </div>`;
            html += `        </div>`;
            html += `</div>`;
            html += `        </div>`;
            html += `        `;
            html += `        <div class="form-group row">`;
            html += `        <div class="col-4">`;
            html += `            <table`;
            html += `                class="table table-head-noborder table-active table-responsive-sm loading-table table-foot-bg">`;
            html += `                <thead>`;
            html += `                <tr>`;
            html += `                    <th>YARN CERTIFICATION TYPE</th>`;
            html += `                    <th style="width:100px;">ADD/DELETE</th>`;
            html += `                </tr>`;
            html += `                </thead>`;
            html += `                <tbody id="tbl_yarn_certification_types">`;
            html += `<tr class="tr">`;
            html += `    <td style="vertical-align: middle">`;
            html += `        <select name="order_details[${count}][yarn_certification_type_id][]"`;
            html += `                class="form-control">`;
            html += `            <option value="">Select</option>`;
            <?php $__currentLoopData = $yarn_certification_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                html += `            <option`;
            html += `                value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>`;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                html += `        </select>`;
            html += `    </td>`;
            html += `    <td>`;
            html += `        <button`;
            html += `            class="btn btn-icon btn-sm btn-primary btn-circle"`;
            html += `            type="button" onclick="add_yarn_certification_type(${count})"><i`;
            html += `            class="fa fa-plus"></i></button>`;
            html += `        <button class="btn btn-icon btn-danger btn-sm btn-circle" type="button"`;
            html += `                onclick="deleteRow(this)"><i class="fa fa-trash"></i></button>`;
            html += `    </td>`;
            html += `</tr>`;
            html += `                </tbody>`;
            html += `            </table>`;
            html += `        </div>`;
            html += `        <div class="col-4">`;
            html += `            <label>Costing Number</label>`;
            html += `            <input type="number" name="order_details[${count}][costing_number]"`;
            html += `                   class="form-control" autocomplete="off" />`;
            html += `        </div>`;
            html += `        </div>`;
            html += `</div>`;
            $('#order_details').append(html);
        };

        const deleteRow = (val) => {
            $(val).closest('.tr').remove();
            console.log($(val).closest('tr'));
        }
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\erp_new-main\resources\views/sales_order/add.blade.php ENDPATH**/ ?>
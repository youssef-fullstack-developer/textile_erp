<?php $__env->startSection('content'); ?>
    <?php
        if(empty($item)){
            $item = NULL;
        }
        $action = $item?->id > 0 ? '/shades/'.$item?->id : '/shades' ;
    ?>
    <?php echo e(html()->form('POST', $action)->open()); ?>

    <?php if($item?->id > 0): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-custom " id="kt_page_sticky_card">
                <div class="card-header">
                    <div class="card-title">
                        <h3 class="card-label">
                            <?php echo e($item?->id > 0 ? 'Edit' : 'Add'); ?> Shade
                        </h3>
                    </div>
                    <div class="card-toolbar">
                        <a href="<?php echo e(route('shades.index')); ?>" class="btn btn-light-primary font-weight-bolder mr-2">
                            <i class="ki ki-long-arrow-back icon-sm"></i>
                            Back
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Shade:</label>
                            <input type="text" name="name" class="form-control" id="name" autocomplete="off"
                                   placeholder="Enter Shade" value="<?php echo e($item ? $item->name : old('name')); ?>" required/>
                        </div>

                        <div class="col-4">
                            <label>Parent Sort:</label>
                            <select name="parent_sort_id" id="parent_sort_id" class="form-control"
                                    onchange="parent_sort_changed()">
                                <option value="">Select Parent Sort</option>
                                <?php $__currentLoopData = $sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($one->id); ?>" <?php echo e(($item?->parent_sort_id == $one->id) ? 'selected' : ''); ?>

                                    ><?php echo e($one->sort_no); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-12">
                            <table class="table table-bordered table-hover">
                                <tr>
                                    <th>WARP/WEFT</th>
                                    <th>PATTERN</th>
                                    <th>ACTUAL MATERIAL</th>
                                    <th>MATERIAL</th>
                                </tr>
                                <tbody id="tbl">
                                
                                <?php if(!empty($item->warps)): ?>
                                <?php $__currentLoopData = $item->warps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>Warp<?php echo e($key+1); ?></td>
                                        <td><?php echo e($one->actual_material?->warp_pattern); ?></td>
                                        <td>
                                            <input type="hidden" name="warps[<?php echo e($key); ?>][actual_id]"
                                                   value="<?php echo e($one->actual_material?->material?->id); ?>"><?php echo e($one->actual_material?->material?->name); ?>

                                        </td>
                                        <td>
                                            <select class="form-control" name="warps[<?php echo e($key); ?>][material_id]">
                                                <option value="">Select Material</option>
                                                <?php $__currentLoopData = $yarns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($yarn->id); ?>" <?php echo e($one->material_id == $yarn->id ? 'selected' : ''); ?>><?php echo e($yarn->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                <?php if(!empty($item->wefts)): ?>
                                    <?php $__currentLoopData = $item->wefts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>Weft<?php echo e($key+1); ?></td>
                                        <td><?php echo e($one->actual_material?->weft_pattern); ?></td>
                                        <td>
                                            <input type="hidden" name="wefts[<?php echo e($key); ?>][actual_id]"
                                                   value="<?php echo e($one->actual_material?->material?->id); ?>"><?php echo e($one->actual_material?->material?->name); ?>

                                        </td>
                                        <td>
                                            <select class="form-control" name="wefts[<?php echo e($key); ?>][material_id]">
                                                <option value="">Select Material</option>
                                                <?php $__currentLoopData = $yarns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($yarn->id); ?>" <?php echo e($one->material_id == $yarn->id ? 'selected' : ''); ?>><?php echo e($yarn->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" name="submit" value="submit" class="btn btn-primary font-weight-bolder">
                            <i class="ki ki-check icon-sm"></i>
                            Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php echo e(html()->form()->close()); ?>

        <?php $__env->stopSection(); ?>
        <?php $__env->startPush('scripts'); ?>

            <script>
                function parent_sort_changed() {
                    $('#tbl').html('');
                    let id = $("#parent_sort_id").val();
                    $.ajax({
                        url: 'get_sort',
                        type: 'GET',
                        data: {
                            'id': id,
                        },
                        dataType: 'json',
                        success: function (data) {
                            $.each(data.item.warps, function (index, item) {
                                let tr = '<tr>';
                                tr += `<td>Warp${index + 1}</td>`;
                                tr += `<td>${item.warp_pattern}</td>`;
                                tr += `<td><input type="hidden" name="warps[${index}][actual_id]" value="${item.material.id}">${item.material.name}</td>`;
                                tr += `<td>`;
                                tr += `<select class="form-control" name="warps[${index}][material_id]">`;
                                tr += `<option value="">Select Material</option>`;
                                <?php $__currentLoopData = $yarns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    tr += `<option value="<?php echo e($yarn->id); ?>"><?php echo e($yarn->name); ?></option>`;
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    tr += `</select>`;
                                tr += `</td>`;
                                tr += `</tr>`;
                                $('#tbl').append(tr);
                            });
                            $.each(data.item.wefts, function (index, item) {
                                let tr = '<tr>';
                                tr += `<td>Weft${index + 1}</td>`;
                                tr += `<td>${item.weft_pattern}</td>`;
                                tr += `<td><input type="hidden" name="wefts[${index}][actual_id]" value="${item.material.id}">${item.material.name}</td>`;
                                tr += `<td>`;
                                tr += `<select class="form-control" name="wefts[${index}][material_id]" required>`;
                                tr += `<option value="">Select Material</option>`;
                                <?php $__currentLoopData = $yarns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    tr += `<option value="<?php echo e($yarn->id); ?>"><?php echo e($yarn->name); ?></option>`;
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    tr += `</select>`;
                                tr += `</td>`;
                                tr += `</tr>`;
                                $('#tbl').append(tr);
                            });
                        }
                    });
                }

                $(document).ready(function () {


                });
            </script>

    <?php $__env->stopPush(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\erp_new-main\resources\views/shades/add.blade.php ENDPATH**/ ?>
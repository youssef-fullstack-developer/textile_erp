<?php $__env->startSection('content'); ?>
    <div class="card card-custom" style="box-shadow: none">
        <div class="card-header flex-wrap border-0 pt-0 pb-0">
            <div class="card-title">
                <h3 class="card-label">
                    Export Invoice List
                </h3>
            </div>
        </div>
        <hr>
        <div class="card-body">
            <table class="table table-bordered table-hover" id="table_invoice_settings">
                <thead>
                    <tr class="text-uppercase">
                        <th>id</th>
                        <th class="pl-7"><span class="text-dark-75">No.</span></th>
                        <th class="pl-7"><span class="text-dark-75">Custom Invoice</span></th>
                        <th class="pl-7"><span class="text-dark-75">Commercial Invoice</span></th>
                        <th class="pl-7"><span class="text-dark-75">Custom Packing List</span></th>
                        <th class="pl-7"><span class="text-dark-75">Buyer Packing List</span></th>
                        <th class="pl-7"><span class="text-dark-75">Tax Invoice</span></th>
                        <th class="pl-7"><span class="text-dark-75">Quality Certificate</span></th>
                        <th class="pl-7"><span class="text-dark-75">SDF Form</span></th>
                        <th class="pl-7"><span class="text-dark-75">DBK Declaration</span></th>
                        <th class="pl-7"><span class="text-dark-75">FEMA Declaration</span></th>
                        <th class="pl-7"><span class="text-dark-75">Bank Covering Letter</span></th>
                        <th class="pl-7"><span class="text-dark-75">BOE Certificate</span></th>
                        <th class="pl-7"><span class="text-dark-75">Inspection Certificate</span></th>
                        <th class="pl-7"><span class="text-dark-75">Annexure</span></th>
                        <th class="pl-7"><span class="text-dark-75">VGM</span></th>
                        <th class="pl-7"><span class="text-dark-75">Self Sealing</span></th>
                        <th class="pl-7"><span class="text-dark-75">Fabric Detail Sheet</span></th>
                        <th class="pl-7"><span class="text-dark-75">Shipment Bill</span></th>
                        <th class="pl-7"><span class="text-dark-75">Forwarder to Invoice</span></th>
                        <th class="pl-7"><span class="text-dark-75">Transport Details</span></th>
                        <th class="pl-7"><span class="text-dark-75">E - Invoice</span></th>
                        <th class="pl-7"><span class="text-dark-75">E - Invoice</span></th>
                        <th class="pl-7"><span class="text-dark-75">E - Waybill</span></th>
                        <th class="pl-7"><span class="text-dark-75">E - Waybill</span></th>
                        <th class="pl-7"><span class="text-dark-75">E - Waybill</span></th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($buyers)): ?>
                        <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($buyer->name); ?></td>
                                <td><?php echo e($buyer->no); ?></td>
                                <td><?php echo e($buyer->country); ?></td>
                                <td><?php echo e($buyer->state); ?></td>
                                <td><?php echo e($buyer->city); ?></td>
                                <td><?php echo e($buyer->address); ?></td>
                                <td><?php echo e($buyer->pincode); ?></td>
                                <td><?php echo e($buyer->representative); ?></td>
                                <td><?php echo e($buyer->created_in); ?></td>
                                <td><?php echo e($buyer->status); ?></td>
                                <td class="d-flex">
                                    <a href="<?php echo e(route('buyers.edit', $buyer->id)); ?>"
                                        class="btn btn-warning btn-sm btn-clean btn-icon" title="Edit details">
                                        <i class="la la-edit"></i>
                                    </a>
                                    <?php echo e(html()->form('DELETE', '/buyers/' . $buyer->id)->open()); ?>

                                    <button type="submit" class="btn btn-danger btn-sm btn-clean btn-icon ml-3"
                                        title="Delete">
                                        <i class="la la-trash"></i>
                                    </button>
                                    <?php echo e(html()->form()->close()); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="assets/custom/datatables/datatables.bundle.js"></script>
    <script src="assets/js/datatables/invoice_settings.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\erp_new-main\resources\views/exports/invoice/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <?php
        if(empty($item)){
            $item = NULL;
        }
        $action = $item?->id > 0 ? '/buyers/'.$item?->id : '/buyers' ;
    ?>
    <?php echo e(html()->form('POST', $action)->open()); ?>

    <?php if($item?->id > 0): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-custom " id="kt_page_sticky_card">
                <div class="card-header">
                    <div class="card-title">
                        <h3 class="card-label">
                            <?php echo e($item?->id > 0 ? 'Edit' : 'Add'); ?> Buyers
                        </h3>
                    </div>
                    <div class="card-toolbar">
                        <a href="<?php echo e(route('buyers.index')); ?>" class="btn btn-light-primary font-weight-bolder mr-2">
                            <i class="ki ki-long-arrow-back icon-sm"></i>
                            Back
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Name<b class="text-danger">*</b></label>
                            <input type="text" name="name" class="form-control" id="name" autocomplete="off"
                                   placeholder="Enter Name" value="<?php echo e($item ? $item->name : old('name')); ?>" required/>
                        </div>

                        <div class="col-4">
                            <label>GST Number</label>
                            <input type="number" name="gst" class="form-control" id="gst" autocomplete="off"
                                   placeholder="" value="<?php echo e($item ? $item->gst : old('gst')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Buyer Country<b class="text-danger">*</b></label>
                            <select name="country_id" class="form-control" required>
                                <option value="">Select Country</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>" <?php echo e(($item?->country_id == $country->id) ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <label>State:</label>
                            <select name="state_id" class="form-control">
                                <option value="">Select State</option>
                                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($state->id); ?>" <?php echo e(($item?->state_id == $state->id) ? 'selected' : ''); ?>><?php echo e($state->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-4">
                            <label>Buyer Address 1<b class="text-danger">*</b></label>
                            <input type="text" name="address_1" class="form-control" id="address_1" autocomplete="off"
                                   placeholder="Enter Address" value="<?php echo e($item ? $item->address_1 : old('address_1')); ?>" required/>
                        </div>
                        <div class="col-4">
                            <label>Buyer Address 2:</label>
                            <input type="text" name="address_2" class="form-control" id="address_2" autocomplete="off"
                                   placeholder="Enter Address" value="<?php echo e($item ? $item->address_2 : old('address_2')); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Buyer Address 3:</label>
                            <input type="text" name="address_3" class="form-control" id="address_3" autocomplete="off"
                                   placeholder="Enter Address" value="<?php echo e($item ? $item->address_3 : old('address_3')); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Buyer City:</label>
                            <select name="city_id" class="form-control">
                                <option value="">Select City</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>" <?php echo e(($item?->city_id == $city->id) ? 'selected' : ''); ?>><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Buyer Phone no:</label>
                            <input type="text" name="phone" class="form-control" id="phone" autocomplete="off"
                                   placeholder="Enter Phone" value="<?php echo e($item ? $item->phone : old('phone')); ?>"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Buyer Pincode<b class="text-danger">*</b></label>
                            <input type="text" name="buyer_pincode" class="form-control" id="buyer_pincode"
                                   autocomplete="off" placeholder="Enter Pincode"
                                   value="<?php echo e($item ? $item->buyer_pincode : old('buyer_pincode')); ?>" required/>
                        </div>
                        <div class="col-4">
                            <label>Buyer Email Id :</label>
                            <input type="text" name="email" class="form-control" id="email" autocomplete="off"
                                   placeholder="Enter Email Id" value="<?php echo e($item ? $item->email : old('email')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>Buyer No:</label>
                            <input type="text" name="buyer_no" class="form-control" id="buyer_no" autocomplete="off"
                                   placeholder="Enter buyer no" value="<?php echo e($item ? $item->buyer_no : old('buyer_no')); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Buyer Code:</label>
                            <input type="text" name="buyer_code" class="form-control" id="buyer_code" autocomplete="off"
                                   placeholder="Enter buyer code" value="<?php echo e($item ? $item->buyer_code : old('buyer_code')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>Bank:</label>
                            <input type="text" name="bank" class="form-control" id="bank" autocomplete="off"
                                   placeholder="Enter Bank" value="<?php echo e($item ? $item->bank : old('bank')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>Bank Country:</label>
                            <select name="bank_country_id" class="form-control">
                                <option value="">Select country</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>" <?php echo e(($item?->bank_country_id == $country->id) ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Bank State:</label>
                            <select name="bank_state_id" class="form-control">
                                <option value="">Select Bank State</option>
                                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($state->id); ?>" <?php echo e(($item?->bank_state_id == $state->id) ? 'selected' : ''); ?>><?php echo e($state->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-4">
                            <label>State Code:</label>
                            <input type="text" name="state_code" class="form-control" id="buyer_code" autocomplete="off"
                                   placeholder="Enter State code" value="<?php echo e($item ? $item->state_code : old('state_code')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>Bank Address:</label>
                            <textarea placeholder="" name="bank_address" rows="3" class="form-control"
                            ><?php echo e($item ? $item->bank_address : old('bank_address')); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Pincode:</label>
                            <input type="text" name="pincode" class="form-control" id="pincode" autocomplete="off"
                                   value="<?php echo e($item ? $item->pincode : old('pincode')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>Bank City:</label>
                            <select name="bank_city_id" class="form-control">
                                <option value="">Select Bank City</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>" <?php echo e(($item?->bank_city_id == $city->id) ? 'selected' : ''); ?>><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <div class="checkbox-list mt-5">
                                <label class="checkbox">
                                    <input type="checkbox" name="is_active" value="1" class="form-control"
                                        <?php echo e($item ? ($item->is_active == 1 ? 'checked' : '') : 'checked'); ?>/>
                                    <span></span>
                                    Is Active
                                </label>
                            </div>
                        </div>
                        <div class="col-4">
                            <label>Credit Limit:</label>
                            <input type="text" name="credit_limit" class="form-control" id="credit_limit"
                                   autocomplete="off"
                                   value="<?php echo e($item ? $item->credit_limit : old('credit_limit')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>Interest %:</label>
                            <input type="text" name="interest" class="form-control" id="interest" autocomplete="off"
                                   value="<?php echo e($item ? $item->interest : old('interest')); ?>"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <label>GST Reg. Type<b class="text-danger">*</b></label>
                            <select name="gst_type" class="form-control" required>
                                <option value="" >Select GST Reg. Type</option>
                                <option value="registered_b2b" <?php echo e(($item?->gst_type == 'registered_b2b') ? 'selected' : ''); ?>>Registered B2B</option>
                                <option value="unregistered_b2b" <?php echo e(($item?->gst_type == 'unregistered_b2b') ? 'selected' : ''); ?>>UnRegistered B2B</option>
                                <option value="export" <?php echo e(($item?->gst_type == 'export') ? 'selected' : ''); ?>>Export</option>
                                <option value="ecommerce" <?php echo e(($item?->gst_type == 'ecommerce') ? 'selected' : ''); ?>>ECommerce</option>
                                <option value="sez" <?php echo e(($item?->gst_type == 'sez') ? 'selected' : ''); ?>>SEZ</option>
                                <option value="deemed_export" <?php echo e(($item?->gst_type == 'deemed_export') ? 'selected' : ''); ?>>Deemed Export</option>
                                <option value="composite" <?php echo e(($item?->gst_type == 'composite') ? 'selected' : ''); ?>>Composite</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <div class="checkbox-list mt-5">
                                <label class="checkbox">
                                    <input type="checkbox" name="consignee_as_buyer" value="1" class="form-control"
                                        <?php echo e($item ? ($item->consignee_as_buyer == 1 ? 'checked' : '') : 'checked'); ?> />
                                    <span></span>
                                    Consignee as a buyer
                                </label>
                            </div>
                        </div>
                        <div class="col-4">
                            <label>Account Group:</label>
                            <select name="account_group" class="form-control">
                                <option value="">Select Account Group</option>
                                <option value="land" <?php echo e(($item?->account_group == 'land') ? 'selected' : ''); ?>>Land</option>
                                <option value="building" <?php echo e(($item?->account_group == 'building') ? 'selected' : ''); ?>>Building</option>
                                <option value="plant_machinery" <?php echo e(($item?->account_group == 'plant_machinery') ? 'selected' : ''); ?>>Plant & Machinery</option>
                                <option value="equipments" <?php echo e(($item?->account_group == 'equipments') ? 'selected' : ''); ?>>Equipments</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Group:</label>
                            <select name="vendor_group_id" class="form-control">
                                <option value="">Select vendor group</option>
                                <?php $__currentLoopData = $vendor_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor_group->id); ?>" <?php echo e(($item?->vendor_group_id == $vendor_group->id) ? 'selected' : ''); ?>><?php echo e($vendor_group->group); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-4">
                            <label>Tax Id:</label>
                            <input type="text" name="tax_id" class="form-control" id="tax_id" autocomplete="off"
                                   value="<?php echo e($item ? $item->tax_id : old('tax_id')); ?>"/>
                        </div>
                        <div class="col-4">
                            <label>Pan Number:</label>
                            <input type="text" name="pan" class="form-control" id="pan" autocomplete="off"
                                   value="<?php echo e($item ? $item->pan : old('pan')); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Port Of Loading:</label>
                            <select name="port_landing" class="form-control">
                                <option value="">Select Port Of Landing</option>
                                <?php $__currentLoopData = $ports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $port): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($port->id); ?>" <?php echo e(($item?->port_landing == $port->id) ? 'selected' : ''); ?>><?php echo e($port->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-4">
                            <label>Port Of Destination:</label>
                            <select name="port_destination" class="form-control">
                                <option value="">Select Port Of Destination</option>
                                <option value="bangalore" <?php echo e(($item?->port_destination == 'bangalore') ? 'selected' : ''); ?>>Bangalore</option>
                                <option value="haryana" <?php echo e(($item?->port_destination == 'haryana') ? 'selected' : ''); ?>>Haryana</option>
                                <option value="krishnagiri" <?php echo e(($item?->port_destination == 'krishnagiri') ? 'selected' : ''); ?>>Krishnagiri</option>
                                <option value="katunayake" <?php echo e(($item?->port_destination == 'katunayake') ? 'selected' : ''); ?>>Katunayake</option>
                                <option value="uttar_pardesh" <?php echo e(($item?->port_destination == 'uttar_pardesh') ? 'selected' : ''); ?>>Uttar Pardesh</option>
                                <option value="tiruppur" <?php echo e(($item?->port_destination == 'tiruppur') ? 'selected' : ''); ?>>Tiruppur</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <label>Currency:</label>
                            <select name="currency" class="form-control">
                                <option value="">Select Currency</option>
                                <option value="usd" <?php echo e(($item?->currency == 'usd') ? 'selected' : ''); ?>>USD</option>
                                <option value="rupess" <?php echo e(($item?->currency == 'rupess') ? 'selected' : ''); ?>>RUPEES</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <div class="checkbox-list mt-5">
                                <label class="checkbox">
                                    <input type="checkbox" name="is_self" value="1" class="form-control"
                                        <?php echo e($item ? ($item->is_self == 1 ? 'checked' : '') : 'checked'); ?>/>
                                    <span></span>
                                    Is Self
                                </label>
                            </div>
                        </div>

                    </div>

                    <div class="row my-4">
                        <h3>
                            Buyer Representative
                        </h3>
                    </div>
                    <div class="row form-group">
                        <div class="col-6">
                            <table
                                class="table table-head-noborder table-striped table-responsive-sm loading-table table-foot-bg">
                                <thead>
                                <tr>
                                    <th>REPRESENTATIVE NAME</th>
                                    <th>CONTACT NUMBER</th>
                                    <th>A/D</th>
                                </tr>
                                </thead>
                                <tbody id="tbl">
                                <?php ($i = 0); ?>
                                <?php while( (empty($item) &&  $i == 0) || (count($item?->representatives ?? []) > $i ) ): ?>
                                    <?php ($row = $item ? $item->representatives[$i] : NULL); ?>
                                <tr class="representative">
                                    <td style="vertical-align: middle">
                                        <input type="text" step="any" class="form-control"
                                               name="representatives[<?php echo e($i); ?>][representative_name]"
                                               id="representatives[<?php echo e($i); ?>][representative_name]"
                                               value="<?php echo e($item ? $row?->representative_name : ''); ?>">
                                    </td>
                                    <td style="vertical-align: middle">
                                        <input type="text" step="any" class="form-control"
                                               name="representatives[<?php echo e($i); ?>][representative_phone]"
                                               id="representatives[<?php echo e($i); ?>][representative_phone]"
                                               value="<?php echo e($item ? $row?->representative_phone : ''); ?>">
                                    </td>
                                    <td>
                                       <button class="btn btn-icon btn-sm btn-primary btn-circle" type="button" onclick="addRow()"><i class="fa fa-plus"></i></button>
                                        <button class="btn btn-icon btn-danger btn-sm btn-circle" type="button" onclick="deleteRow(this)" ><i class="fa fa-trash"></i></button>
                                    </td>
                                </tr>
                                <?php ($i++); ?>
                                <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" name="submit" value="submit" class="btn btn-primary font-weight-bolder">
                        <i class="ki ki-check icon-sm"></i>
                        Submit
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php echo e(html()->form()->close()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script>
           const addRow = () => {
                var html = '';
                var index = $('.representative').length;
                html += '<tr class="representative">';
                html += `<td style="vertical-align: middle"><input type="text" step="any" class="form-control" name="representatives[${index}][representative_name]" id="representatives[${index}][representative_name]"></td>`;
                html += `<td style="vertical-align: middle"><input type="text" step="any" class="form-control" name="representatives[${index}][representative_phone]" id="representatives[${index}][representative_phone]"></td>`;
                html += '<td>';
                html += '<button class="btn btn-icon btn-primary btn-sm btn-circle mr-2" type="button" onclick="addRow()" ><i class="fa fa-plus"></i></button>';
                html += '<button class="btn btn-icon btn-danger btn-sm btn-circle" type="button" onclick="deleteRow(this)" ><i class="fa fa-trash"></i></button>';
                html += '</td>';
                html += '</tr>';
                $('#tbl').append(html);
            }

            const deleteRow = (val) => {
                $(val).closest('tr').remove();
            }
        </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\erp_new-main\resources\views/buyers/add.blade.php ENDPATH**/ ?>
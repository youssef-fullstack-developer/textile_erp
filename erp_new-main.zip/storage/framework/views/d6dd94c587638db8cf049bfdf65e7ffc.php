<?php $__env->startSection('content'); ?>
    <?php
    if(empty($item)){
        $item = NULL;
    }
    $action = $item?->id > 0 ? '/yarn/'.$item?->id : '/yarn' ;
 ?>
    <?php echo e(html()->form('POST', $action)->open()); ?>

    <?php if($item?->id > 0): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-custom " id="kt_page_sticky_card">
                <div class="card-header">
                    <div class="card-title">
                        <h3 class="card-label">
                                <?php echo e($item?->id > 0 ? 'Edit' : 'Add'); ?>  Yarn
                        </h3>
                    </div>
                    <div class="card-toolbar">
                        <a href="<?php echo e(route('yarn.index')); ?>" class="btn btn-light-primary font-weight-bolder mr-2">
                            <i class="ki ki-long-arrow-back icon-sm"></i>
                            Back
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Count:</label>
                            <select name="count" id="count" class="form-control" required>
                                <option value="">Select Count</option>
                                <?php $__currentLoopData = $counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($count->id); ?>" <?php echo e(($item?->count == $count->id) ? 'selected' : ''); ?>><?php echo e($count->count); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Ply:</label>
                            <select name="ply" id="ply" class="form-control" required>
                                <option value="">Select Ply</option>
                                <?php $__currentLoopData = $ply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php echo e(($item?->ply == $p->id) ? 'selected' : ''); ?>><?php echo e($p->ply); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Filaments:</label>
                            <select name="filaments" class="form-control">
                                <option value="">Select Filaments</option>
                                <?php $__currentLoopData = $filaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->filaments == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-4">
                            <label>Yarn Type:</label>
                            <select name="type" id="yarn_type" class="form-control">
                                <option value="">Select Yarn Type</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($type->id); ?>" <?php echo e(($item?->type == $type->id) ? 'selected' : ''); ?>><?php echo e($type->type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Yarn Unit:</label>
                            <select name="unit" id="yarn_unit" class="form-control" required>
                                <option value="">Select Yarn Unit</option>
                                <?php $__currentLoopData = $uom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($u->id); ?>" <?php echo e(($item?->unit == $u->id) ? 'selected' : ''); ?>><?php echo e($u->code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>TPM:</label>
                            <select name="tpm" class="form-control">
                                <option value="">Select TPM</option>
                                <?php $__currentLoopData = $tpms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->tpm == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Color:</label>
                            <select name="color" id="color" class="form-control">
                                <option value="">Select Color</option>
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($color->id); ?>" <?php echo e(($item?->color == $color->id) ? 'selected' : ''); ?>><?php echo e($color->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Yarn Variety:</label>
                            <select name="variety" id="variety" class="form-control" required>
                                <option value="">Select Variety</option>
                                <?php $__currentLoopData = $varieties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variety): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($variety->id); ?>" <?php echo e(($item?->variety == $variety->id) ? 'selected' : ''); ?>><?php echo e($variety->code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Reorder Quantity Level:</label>
                            <input type="text" class="form-control" name="reorder"
                                   value="<?php echo e($item ? $item->reorder : ''); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Buying UOM:</label>
                            <select name="buy_uom" id="buy_uom" class="form-control" required>
                                <option value="">Select Color</option>
                                <?php $__currentLoopData = $buy_uom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($uom->id); ?>" <?php echo e(($item?->buy_uom == $uom->id) ? 'selected' : ''); ?>><?php echo e($uom->code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Blend:</label>
                            <select name="blend" class="form-control">
                                <option value="">Select Blend</option>
                                <?php $__currentLoopData = $blends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($row->id); ?>" <?php echo e(($item?->blend == $row->id) ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-4">
                            <label>Danger Quantity Level:</label>
                            <input type="text" class="form-control" name="danger"
                                   value="<?php echo e($item ? $item->danger : ''); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <label>Yarn Name:</label>
                            <input type="text" id="name" class="form-control" name="name"
                                   value="<?php echo e($item ? $item->name : ''); ?>" readonly/>
                        </div>

                        <div class="col-4">
                            <label>Conversion Count:</label>
                            <input type="text" class="form-control" name="conversion"
                                   value="<?php echo e($item ? $item->conversion : ''); ?>"/>
                        </div>

                        <div class="col-4">
                            <label>Dsiplay Name:</label>
                            <input type="text" id="display_name" class="form-control" name="display_name"
                                   value="<?php echo e($item ? $item->display_name : ''); ?>"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-4">
                            <div class="form-group row">
                                <div class="col-12">
                                    <label>Apply Ply for Conversion:</label>
                                    <div class="col-form-label">
                                        <div class="radio-inline">
                                            <label class="radio radio-success">
                                                <input type="radio" name="is_apply" value="1"
                                                    <?php echo e($item ? ($item->is_apply == 1 ? 'checked' : '') : 'checked'); ?> />
                                                <span></span>
                                                Yes
                                            </label>
                                            <label class="radio radio-danger">
                                                <input type="radio" name="is_apply" value="0"
                                                    <?php echo e($item ? ($item->is_apply == 0 ? 'checked' : '') : ''); ?>/>
                                                <span></span>
                                                No
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group row">
                                <div class="col-12">
                                    <label>Status:</label>
                                    <div class="col-form-label">
                                        <div class="radio-inline">
                                            <label class="radio radio-success">
                                                <input type="radio" name="status" value="1"
                                                    <?php echo e($item ? ($item->status == 1 ? 'checked' : '') : 'checked'); ?>/>
                                                <span></span>
                                                Active
                                            </label>
                                            <label class="radio radio-danger">
                                                <input type="radio" name="status" value="0"
                                                    <?php echo e($item ? ($item->status == 0 ? 'checked' : '') : ''); ?>/>
                                                <span></span>
                                                Inactive
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-2">
                            <label>HSN No:</label>
                            <input type="text" class="form-control" name="hsn" value="<?php echo e($item ? $item->hsn : ''); ?>"/>
                        </div>

                        <div class="col-2">
                            <label>IGST%:</label>
                            <select name="igst" id="igst" class="form-control" required>
                                <option value=""></option>
                                <?php $__currentLoopData = $igst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($line->val); ?>" <?php echo e(($item?->igst == $line->val) ? 'selected' : ''); ?>><?php echo e($line->val); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-2">
                            <label>CGST%:</label>
                            <select name="cgst" id="cgst" class="form-control" required>
                                <option value=""></option>
                                <?php $__currentLoopData = $cgst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($line->val); ?>" <?php echo e(($item?->cgst == $line->val) ? 'selected' : ''); ?>><?php echo e($line->val); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-2">
                            <label>SGST%:</label>
                            <select name="sgst" id="sgst" class="form-control" required>
                                <option value=""></option>
                                <?php $__currentLoopData = $sgst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($line->val); ?>" <?php echo e(($item?->sgst == $line->val) ? 'selected' : ''); ?>><?php echo e($line->val); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-2">
                            <label>Cess%:</label>
                            <input type="text" class="form-control" name="cess" value="<?php echo e($item ? $item->cess : ''); ?>"/>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" name="submit" value="submit" class="btn btn-primary font-weight-bolder">
                        <i class="ki ki-check icon-sm"></i>
                        Submit
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php echo e(html()->form()->close()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#count').on('change', () => {
            updateName()
        })

        $('#ply').on('change', () => {
            updateName()
        })

        $('#yarn_type').on('change', () => {
            updateName()
        })

        $('#yarn_unit').on('change', () => {
            updateName()
        })

        $('#color').on('change', () => {
            updateName()
        })

        $('#variety').on('change', () => {
            updateName()
        })


        function updateName() {
            var count = ''
            var ply = ''
            var yarn_type = ''
            var yarn_unit = ''
            var color = ''
            var variety = ''

            if ($('#count').val()) {
                count = parseInt($('#count option:selected').text())
            }

            if ($('#ply').val()) {
                ply = parseInt($('#ply option:selected').text())
            }

            if ($('#yarn_type').val()) {
                yarn_type = $('#yarn_type option:selected').text()
            }

            if ($('#yarn_unit').val()) {
                yarn_unit = $('#yarn_unit option:selected').text()
            }

            if ($('#color').val()) {
                color = $('#color option:selected').text()
            }

            if ($('#variety').val()) {
                variety = $('#variety option:selected').text()
            }

            $('#name').val(ply + "/" + count + ' ' + yarn_unit + ' ' + yarn_type + ' ' + variety + ' ' + color)
            $('#display_name').val(ply + "/" + count + ' ' + yarn_unit + ' ' + yarn_type + ' ' + variety + ' ' + color)
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\erp_new-main\resources\views/yarn_master/yarn/add.blade.php ENDPATH**/ ?>
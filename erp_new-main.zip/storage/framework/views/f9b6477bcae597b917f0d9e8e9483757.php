<?php $__env->startSection('content'); ?>
    <?php
        $route_main = 'sourcing_executives';
        $module_label = 'Sourcing Executive';
    ?>
    <div class="card card-custom" style="box-shadow: none">
        <div class="card-header flex-wrap border-0 pt-0 pb-0">
            <div class="card-title">
                <h3 class="card-label">
                    <?php echo e($module_label); ?> List
                </h3>
            </div>
            <div class="card-toolbar">
                <button data-toggle="modal" data-target="#storeCurrentModel"
                        class="btn btn-primary font-weight-bolder mr-2">
                    <span class="svg-icon svg-icon-md">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                             height="24px" viewBox="0 0 24 24" version="1.1">
                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <rect x="0" y="0" width="24" height="24"/>
                                <circle fill="#000000" cx="9" cy="15" r="6"/>
                                <path
                                    d="M8.8012943,7.00241953 C9.83837775,5.20768121 11.7781543,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,12.2218457 18.7923188,14.1616223 16.9975805,15.1987057 C16.9991904,15.1326658 17,15.0664274 17,15 C17,10.581722 13.418278,7 9,7 C8.93357256,7 8.86733422,7.00080962 8.8012943,7.00241953 Z"
                                    fill="#000000" opacity="0.3"/>
                            </g>
                        </svg>
                    </span> Add
                </button>
            </div>
        </div>
        <hr>
        <div class="card-body">
            <table class="table table-bordered table-hover" id="table_invoice_settings">
                <thead>
                <tr class="text-uppercase">
                    <th>id</th>
                    <th class="pl-7"><span class="text-dark-75">Name</span></th>
                    <th class="pl-7"><span class="text-dark-75">Active</span></th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php if(!empty($list)): ?>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td>
                                <span class="label label-lg font-weight-bold label-inline label-light-<?php echo e($item->status ?  'success': 'danger'); ?> ">
                                <?php echo e($item->status ?  'Active': 'Inactive'); ?></span>
                            </td>
                            <td class="d-flex">
                                <a href="javascript:void(0)" data-id="<?php echo e($item->id); ?>"
                                   class="btn btn-warning btn-sm btn-clean btn-icon btn-edit" title="Edit details">
                                    <i class="la la-edit"></i>
                                </a>
                                <a href="javascript:void(0)" data-id="<?php echo e($item->id); ?>" title="Delete"
                                   data-toggle="modal" data-target="#deleteCurrentModal"
                                   class="btn btn-danger btn-sm btn-clean btn-icon ml-3  btn-delete">
                                    <i class="la la-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add & Edit Modal -->
    <div class="modal fade" id="storeCurrentModel" tabindex="-1" role="dialog"
         aria-labelledby="storeCurrentModelLabel" aria-hidden="true">
        <?php echo e(html()->form('POST', '/'.$route_main)->id('storeForm')->open()); ?>

        <input type="hidden" name="_method" id="_method" value="">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($module_label); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i aria-hidden="true" class="ki ki-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <div class="col-12">
                            <label>Name<b class="text-danger">*</b></label>
                            <input type="text" name="name" id="name" class="form-control" autocomplete="off"
                                   placeholder="Enter Name" value="<?php echo e(old('name')); ?>" required/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-12">
                            <label>Status:</label>
                            <div class="col-form-label">
                                <div class="radio-inline">
                                    <label class="radio radio-success">
                                        <input type="radio" name="status" id="status_true" checked="checked" value="1"/>
                                        <span></span>
                                        Active
                                    </label>
                                    <label class="radio radio-danger">
                                        <input type="radio" name="status" id="status_false" value="0"/>
                                        <span></span>
                                        Inactive
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light-primary font-weight-bold"
                            data-dismiss="modal">Close
                    </button>
                    <button type="submit" class="btn btn-primary font-weight-bold">Save changes</button>
                </div>
            </div>
        </div>
        <?php echo e(html()->form()->close()); ?>

    </div>

    <!-- Delete Modal -->
    <div class="modal fade" id="deleteCurrentModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <?php echo e(html()->form('POST', '')->id('deleteForm')->open()); ?>

            <?php echo method_field('DELETE'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Delete <?php echo e($module_label); ?></h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this <?php echo e($module_label); ?>?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-danger">Delete</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </div>
            <?php echo e(html()->form()->close()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="assets/custom/datatables/datatables.bundle.js"></script>
    <script src="assets/js/datatables/certifications.js"></script>

    <script>
        $(document).ready(function () {
            $('#storeCurrentModel').on('hidden.bs.modal', function () {
                $('#storeForm').attr('action', '/<?php echo e($route_main); ?>');
                $('#storeForm').attr('method', 'post');
                $('#_method').val('');
                $('#name').val('');
                $('#status_true').prop("checked", true);
                $('#status_false').prop("checked", false);
            });


            $('.btn-edit').on('click', function () {
                let id = $(this).data('id');
                $.get('/<?php echo e($route_main); ?>/' + id + '/edit', function (data) {
                    $('#storeForm').attr('action', '/<?php echo e($route_main); ?>/' + id);
                    $('#_method').val('PUT');
                    $('#name').val(data.name);
                    if (data.status === true || data.status === 1) {
                        $('#status_true').prop("checked", true);
                        $('#status_false').prop("checked", false);
                    } else {
                        $('#status_true').prop("checked", false);
                        $('#status_false').prop("checked", true);
                    }
                    $('#storeCurrentModel').modal('show');
                });
            });


            $('.btn-delete').on('click', function () {
                let id = $(this).data('id');
                $('#deleteForm').attr('action', '/<?php echo e($route_main); ?>/' + id);
            });


        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\erp_new-main\resources\views/sourcing_executive/index.blade.php ENDPATH**/ ?>